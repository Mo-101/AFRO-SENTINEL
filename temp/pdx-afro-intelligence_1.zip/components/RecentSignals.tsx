
import React from 'react';
import { Signal, AlertLevel } from '../types';

interface RecentSignalsProps {
  signals: Signal[];
  isLoading: boolean;
  onSignalClick: (s: Signal) => void;
}

export const RecentSignals: React.FC<RecentSignalsProps> = ({ signals, isLoading, onSignalClick }) => {
  const sortedSignals = [...signals].sort((a, b) => new Date(b.publishedAt || Date.now()).getTime() - new Date(a.publishedAt || Date.now()).getTime());

  return (
    <div className="w-80 bg-white border-l border-slate-200 hidden xl:flex flex-col h-full shrink-0">
      <div className="p-6 border-b border-slate-100">
        <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Live Stream</h3>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Incoming Validation Packets</p>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {isLoading && signals.length === 0 ? (
           <div className="p-6 space-y-4">
             {[1,2,3,4].map(i => <div key={i} className="h-20 bg-slate-50 rounded-xl animate-pulse"></div>)}
           </div>
        ) : (
          <div className="divide-y divide-slate-50">
            {sortedSignals.map(signal => (
              <div 
                key={signal.id} 
                onClick={() => onSignalClick(signal)}
                className="p-5 hover:bg-slate-50 cursor-pointer transition-colors group"
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={`w-2 h-2 rounded-full mt-1.5 ${
                    signal.level === AlertLevel.CRITICAL ? 'bg-red-500 animate-pulse' : 
                    signal.level === AlertLevel.HIGH ? 'bg-orange-500' : 'bg-emerald-500'
                  }`}></span>
                  <span className="text-[9px] font-black text-slate-400 uppercase">{signal.publishedAt}</span>
                </div>
                <h5 className="text-sm font-bold text-slate-800 leading-snug group-hover:text-blue-600 transition-colors mb-1">{signal.headline}</h5>
                <p className="text-[10px] text-slate-500 font-medium line-clamp-2">{signal.summary}</p>
                <div className="flex items-center gap-2 mt-3">
                   <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider bg-slate-100 px-1.5 py-0.5 rounded">{signal.location?.country || 'Unknown'}</span>
                   {signal.epi?.deaths !== undefined && <span className="text-[9px] font-black text-red-400 uppercase tracking-wider bg-red-50 px-1.5 py-0.5 rounded">{signal.epi.deaths} Deaths</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
