import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, Legend, PieChart, Pie, Cell 
} from 'recharts';
import { ArrowUp, Activity, AlertTriangle, ShieldAlert, Radio, Clock } from 'lucide-react';
import { API_SOURCES } from '../constants';
import { PDXAlert } from '../types';

interface DashboardProps {
  alerts: PDXAlert[];
}

const COLORS = ['#0ea5e9', '#f59e0b', '#ef4444', '#8b5cf6', '#10b981'];

const StatCard: React.FC<{ 
  title: string; 
  value: string | number; 
  subtext?: string; 
  icon: React.ReactNode; 
  accentColor?: string;
}> = ({ title, value, subtext, icon, accentColor = 'text-blue-600' }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <h3 className="text-2xl font-bold text-slate-900 mt-2">{value}</h3>
        </div>
        <div className={`p-3 bg-slate-50 rounded-lg ${accentColor}`}>
          {icon}
        </div>
      </div>
      {subtext && (
        <div className="mt-4 flex items-center text-sm text-slate-500">
          <span className="font-medium">{subtext}</span>
        </div>
      )}
    </div>
  );
};

export const Dashboard: React.FC<DashboardProps> = ({ alerts }) => {
  // 1. Calculate Core Metrics
  const highPriorityCount = alerts.filter(a => a.severity === 'CRITICAL' || a.severity === 'HIGH').length;
  const activeSourcesCount = API_SOURCES.filter(s => s.status === 'active').length;
  const totalSignalsProcessed = alerts.reduce((acc, curr) => acc + (curr.evidence.signal_count || 0), 0);
  const totalAlerts = alerts.length;

  // 2. Calculate Disease Distribution (Pie Chart)
  const distMap = new Map<string, number>();
  alerts.forEach(a => {
    // Group by Hazard or Disease Name, or Fallback
    const key = a.hazard || a.disease?.name || 'Unspecified';
    distMap.set(key, (distMap.get(key) || 0) + 1);
  });
  
  const diseaseDistributionData = Array.from(distMap.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5); // Top 5

  // 3. Calculate Timeline Data (Line Chart)
  // Group by Date (Day)
  const timelineMap: Record<string, { dateStr: string, signals: number, alerts: number, sortTime: number }> = {};
  
  alerts.forEach(a => {
    const d = new Date(a.created_at);
    // Use ISO date string (YYYY-MM-DD) for grouping
    const dateKey = d.toISOString().split('T')[0];
    // Formatted label for display (e.g., "Oct 24")
    const dateLabel = d.toLocaleDateString('en-GB', { month: 'short', day: 'numeric' });

    if (!timelineMap[dateKey]) {
      timelineMap[dateKey] = { dateStr: dateLabel, signals: 0, alerts: 0, sortTime: d.getTime() };
    }
    timelineMap[dateKey].signals += (a.evidence.signal_count || 0);
    timelineMap[dateKey].alerts += 1;
  });

  const timelineData = Object.values(timelineMap).sort((a, b) => a.sortTime - b.sortTime);

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Active Alerts" 
          value={totalAlerts} 
          subtext="Detected in last 7 days"
          icon={<AlertTriangle className="w-5 h-5" />}
          accentColor="text-orange-600"
        />
        <StatCard 
          title="High Severity" 
          value={highPriorityCount} 
          subtext="Requires immediate attention"
          icon={<ShieldAlert className="w-5 h-5" />}
          accentColor="text-red-600"
        />
        <StatCard 
          title="Signals Processed" 
          value={totalSignalsProcessed.toLocaleString()} 
          subtext="Data points analyzed"
          icon={<Radio className="w-5 h-5" />}
          accentColor="text-blue-600"
        />
        <StatCard 
          title="Active Sources" 
          value={`${activeSourcesCount}/${API_SOURCES.length}`} 
          subtext="Live API Connections"
          icon={<Activity className="w-5 h-5" />}
          accentColor="text-emerald-600"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Signal Trend - Calculated from Live Data */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-6 flex items-center">
            <Clock className="w-5 h-5 mr-2 text-slate-400" />
            Detection Timeline (Live)
          </h3>
          <div className="h-80">
            {timelineData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="dateStr" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} dy={10} />
                  <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                  <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                  <Tooltip 
                    contentStyle={{backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} 
                  />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="signals" stroke="#0ea5e9" strokeWidth={3} dot={{r: 4}} activeDot={{r: 6}} name="Raw Signals" />
                  <Line yAxisId="right" type="monotone" dataKey="alerts" stroke="#ef4444" strokeWidth={3} dot={{r: 4}} name="Validated Alerts" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400">
                <p>Waiting for live data stream...</p>
              </div>
            )}
          </div>
        </div>

        {/* Disease Distribution - Calculated from Live Data */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-6">Top Event Types (Live)</h3>
          <div className="h-80">
            {diseaseDistributionData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={diseaseDistributionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {diseaseDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                     contentStyle={{backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0'}} 
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400">
                <p>Waiting for live data stream...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};