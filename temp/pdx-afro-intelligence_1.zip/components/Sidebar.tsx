
import React, { useState } from 'react';
import { Country } from '../types';
import { AFRO_COUNTRIES } from '../constants';
import { Globe, Settings2 } from 'lucide-react';

interface SidebarProps {
  selectedCountry: string;
  onSelectCountry: (c: string) => void;
  children?: React.ReactNode;
}

const Sidebar: React.FC<SidebarProps> = ({ selectedCountry, onSelectCountry, children }) => {
  const [activeTab, setActiveTab] = useState<'states' | 'filters'>('states');

  return (
    <div className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col h-full shrink-0 relative z-40">
      <div className="p-6 border-b border-slate-800 bg-slate-900 sticky top-0 z-10">
        <h1 className="text-xl font-black text-white tracking-tighter uppercase">PDX AFRO <span className="text-emerald-500">INTEL</span></h1>
        <div className="flex items-center gap-2 mt-2">
           <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
           <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">System Online</span>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="px-6 py-4 flex gap-2 border-b border-slate-800/50">
        <button 
          onClick={() => setActiveTab('states')}
          className={`flex-1 flex flex-col items-center py-3 rounded-xl transition-all ${activeTab === 'states' ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-xl' : 'text-slate-500 hover:text-slate-400'}`}
        >
          <Globe className="w-4 h-4 mb-1" />
          <span className="text-[9px] font-black uppercase tracking-widest">States</span>
        </button>
        <button 
          onClick={() => setActiveTab('filters')}
          className={`flex-1 flex flex-col items-center py-3 rounded-xl transition-all ${activeTab === 'filters' ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-xl' : 'text-slate-500 hover:text-slate-400'}`}
        >
          <Settings2 className="w-4 h-4 mb-1" />
          <span className="text-[9px] font-black uppercase tracking-widest">Filters</span>
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {activeTab === 'states' ? (
          <div className="p-3 space-y-1">
            <button
              onClick={() => onSelectCountry('AFRO Regional Panorama')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 flex items-center justify-between ${
                selectedCountry === 'AFRO Regional Panorama' 
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/50' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span>Regional Panorama</span>
              <Globe className="w-4 h-4 opacity-50" />
            </button>

            <div className="pt-4 pb-2 px-4 text-[9px] font-black text-slate-600 uppercase tracking-widest">Member States</div>
            
            {AFRO_COUNTRIES.map((country) => (
              <button
                key={country.code}
                onClick={() => onSelectCountry(country.name)}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-bold transition-colors flex items-center justify-between group ${
                  selectedCountry === country.name
                  ? 'bg-slate-800 text-emerald-400 border border-slate-700' 
                  : 'text-slate-500 hover:bg-slate-800/50 hover:text-slate-200'
                }`}
              >
                <span>{country.name}</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-600 group-hover:bg-slate-700 transition-colors ${
                  selectedCountry === country.name ? 'text-emerald-500' : ''
                }`}>{country.code}</span>
              </button>
            ))}
          </div>
        ) : (
          <div className="h-full bg-slate-900">
            {children}
          </div>
        )}
      </div>
      
      <div className="p-4 border-t border-slate-800 bg-slate-900 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
            <Settings2 className="w-4 h-4 text-slate-400" />
          </div>
          <div>
             <p className="text-[10px] font-black text-white uppercase">Analyst Console</p>
             <p className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">Level 5 Access</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
