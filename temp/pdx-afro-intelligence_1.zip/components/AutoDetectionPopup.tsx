import React from 'react';
import { AutoDetection } from '../types';
import { AlertTriangle, Zap } from 'lucide-react';

interface AutoDetectionPopupProps {
  detections: AutoDetection[];
}

export const AutoDetectionPopup: React.FC<AutoDetectionPopupProps> = ({ detections }) => {
  if (detections.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3 pointer-events-none">
      {detections.map(det => (
        <div key={det.id} className="bg-slate-900 text-white p-4 rounded-xl shadow-2xl border border-slate-700 w-80 pointer-events-auto animate-slide-up">
           <div className="flex items-center gap-2 mb-2 text-amber-400">
             <Zap className="w-4 h-4 fill-current" />
             <span className="text-[10px] font-black uppercase tracking-widest">AI Anomaly Detected</span>
           </div>
           <h4 className="font-bold text-sm mb-1">{det.title}</h4>
           <p className="text-xs text-slate-400 leading-relaxed mb-3">{det.description}</p>
           <div className="flex justify-between items-center pt-2 border-t border-slate-800">
             <span className="text-[10px] font-bold text-slate-500 uppercase">{det.location}</span>
             <span className="text-[10px] font-black text-red-400 bg-red-900/30 px-2 py-0.5 rounded">{det.metric}</span>
           </div>
        </div>
      ))}
    </div>
  );
};
