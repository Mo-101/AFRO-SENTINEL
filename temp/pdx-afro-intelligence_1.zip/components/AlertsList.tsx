
import React, { useState, useMemo } from 'react';
import { PDXAlert, AlertLevel, SeverityLevel } from '../types';
import { Filter, Eye, AlertCircle, MapPin, Activity, X, ExternalLink, Globe2, ShieldCheck, Languages, Megaphone } from 'lucide-react';

interface AlertsListProps {
  alerts: PDXAlert[];
}

const AlertBadge: React.FC<{ level: AlertLevel }> = ({ level }) => {
  const styles: Record<string, string> = {
    [AlertLevel.CRITICAL]: 'bg-red-100 text-red-800 border-red-200',
    [AlertLevel.HIGH]: 'bg-orange-100 text-orange-800 border-orange-200',
    [AlertLevel.MEDIUM]: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    [AlertLevel.LOW]: 'bg-slate-100 text-slate-800 border-slate-200',
  };
  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${styles[level] || 'bg-slate-100 text-slate-800 border-slate-200'}`}>
      {level}
    </span>
  );
};

const SeverityBadge: React.FC<{ severity: SeverityLevel }> = ({ severity }) => {
  const styles = {
    LOW: 'bg-slate-100 text-slate-600',
    MODERATE: 'bg-blue-100 text-blue-800',
    HIGH: 'bg-orange-100 text-orange-800',
    CRITICAL: 'bg-red-600 text-white',
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-medium uppercase ${styles[severity]}`}>
      {severity}
    </span>
  );
};

const AlertDetailModal: React.FC<{ alert: PDXAlert; onClose: () => void }> = ({ alert, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}>
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]" 
        onClick={e => e.stopPropagation()}
      >
        <div className="bg-slate-50 border-b border-slate-200 p-6 flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <AlertBadge level={alert.alert_level} />
              <SeverityBadge severity={alert.severity} />
            </div>
            <h2 className="text-xl font-bold text-slate-900 leading-tight">{alert.title}</h2>
            <div className="flex items-center text-slate-500 text-sm mt-2">
              <MapPin className="w-4 h-4 mr-1" />
              {alert.country_iso3} / {alert.admin1}
              <span className="mx-2">•</span>
              <span className="font-mono">{new Date(alert.created_at).toLocaleDateString()}</span>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto custom-scrollbar">
          <div className="mb-8">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center">
              <Activity className="w-4 h-4 mr-2" />
              Intelligence Summary
            </h3>
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-slate-700 leading-relaxed text-sm">
              {alert.summary}
              <div className="mt-3 pt-3 border-t border-blue-200/50 flex items-center justify-between text-xs text-blue-600">
                <span className="font-medium flex items-center"><ShieldCheck className="w-3 h-3 mr-1"/> Verified Source</span>
                {alert.source_link && (
                  <a href={alert.source_link} target="_blank" rel="noreferrer" className="flex items-center hover:underline">
                    View Original Report <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                )}
              </div>
            </div>
          </div>

          {alert.keywords && (
            <div className="mb-8">
               <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center">
                <Languages className="w-4 h-4 mr-2" />
                Multilingual Keyword Clusters
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                 {Object.entries(alert.keywords).map(([lang, words]: [string, string[]]) => {
                   const isContext = lang === 'context';
                   return (
                   <div key={lang} className={`border rounded-lg p-3 ${isContext ? 'bg-orange-50 border-orange-100' : 'bg-slate-50 border-slate-100'}`}>
                      <div className={`text-[10px] font-bold uppercase mb-1.5 flex items-center ${isContext ? 'text-orange-600' : 'text-slate-400'}`}>
                        {isContext ? <Megaphone className="w-3 h-3 mr-1" /> : <Globe2 className="w-3 h-3 mr-1 opacity-50" />}
                        {lang === 'fr' && 'Français'}
                        {lang === 'pt' && 'Português'}
                        {lang === 'ar' && 'العربية (Arabic)'}
                        {lang === 'sw' && 'Kiswahili'}
                        {lang === 'yo' && 'Yorùbá'}
                        {lang === 'ha' && 'Hausa'}
                        {lang === 'xh' && 'IsiXhosa'}
                        {lang === 'context' && 'Community Context'}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {words.map((word, idx) => (
                          <span key={idx} className={`px-2 py-0.5 rounded border text-xs font-medium shadow-sm ${
                            isContext ? 'bg-white border-orange-200 text-orange-800' : 'bg-white border-slate-200 text-slate-700'
                          }`}>
                            {word}
                          </span>
                        ))}
                      </div>
                   </div>
                   );
                 })}
              </div>
            </div>
          )}

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center">
                <ShieldCheck className="w-4 h-4 mr-2" />
                Validation Metrics
              </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="border border-slate-200 rounded-lg p-4">
                 <div className="text-xs text-slate-500 mb-1">Algorithmic Confidence</div>
                 <div className="flex items-end">
                   <span className="text-2xl font-bold text-slate-900">{(alert.confidence * 100).toFixed(0)}%</span>
                 </div>
                 <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
                    <div className="bg-slate-900 h-1.5 rounded-full" style={{width: `${alert.confidence * 100}%`}}></div>
                 </div>
              </div>
               <div className="border border-slate-200 rounded-lg p-4">
                 <div className="text-xs text-slate-500 mb-1">Source Density</div>
                 <div className="flex items-end">
                   <span className="text-2xl font-bold text-slate-900">{alert.evidence.unique_sources}</span>
                   <span className="ml-2 text-xs text-slate-400 mb-1">Providers</span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const AlertsList: React.FC<AlertsListProps> = ({ alerts }) => {
  const [filterText, setFilterText] = useState('');
  const [selectedAlert, setSelectedAlert] = useState<PDXAlert | null>(null);

  const normalize = (str: string | undefined): string => {
    if (!str) return '';
    return str
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();
  };

  const filteredAlerts = useMemo(() => {
    const searchNormalized = normalize(filterText);
    if (!searchNormalized) return alerts;

    const tokens = searchNormalized.split(/\s+/).filter(t => t.length > 0);

    return alerts.filter((alert) => {
      // 1. Core Metadata Surface
      const metadataSurface = normalize(`${alert.title} ${alert.summary} ${alert.country_iso3} ${alert.admin1} ${alert.hazard} ${alert.disease?.name || ''}`);
      
      // 2. Multilingual Surface (Keywords + Language Names)
      const languageMap: Record<string, string> = { 
        sw: 'swahili kiswahili', ha: 'hausa', yo: 'yoruba', ar: 'arabic', fr: 'french francais', 
        pt: 'portuguese portugues', xh: 'xhosa', context: 'context community' 
      };

      const keywordParts: string[] = [];
      if (alert.keywords) {
        Object.entries(alert.keywords).forEach(([lang, words]) => {
          keywordParts.push(languageMap[lang] || lang);
          words.forEach(w => keywordParts.push(normalize(w)));
        });
      }
      
      const fullSearchSurface = `${metadataSurface} ${keywordParts.join(' ')}`;

      // All search tokens must appear in the combined surface
      return tokens.every(token => fullSearchSurface.includes(token));
    });
  }, [alerts, filterText]);

  return (
    <>
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col h-full">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
             <div className="p-2 bg-slate-900 rounded-lg">
                <Languages className="w-5 h-5 text-emerald-400" />
             </div>
             <h2 className="text-lg font-black text-slate-900 uppercase tracking-tight">Intelligence Stream</h2>
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search across English, Hausa, Swahili, French..."
              className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-96 shadow-inner transition-all"
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[10px] uppercase font-black text-slate-400 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 tracking-widest">Priority</th>
                <th className="px-6 py-4 tracking-widest">Severity</th>
                <th className="px-6 py-4 tracking-widest">Hazard Event</th>
                <th className="px-6 py-4 tracking-widest">Node</th>
                <th className="px-6 py-4 tracking-widest">Evidence</th>
                <th className="px-6 py-4 tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAlerts.map((alert) => (
                <tr key={alert.alert_id} className="hover:bg-slate-50/80 transition-colors cursor-pointer group" onClick={() => setSelectedAlert(alert)}>
                  <td className="px-6 py-4">
                    <AlertBadge level={alert.alert_level} />
                  </td>
                  <td className="px-6 py-4">
                    <SeverityBadge severity={alert.severity} />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-900 leading-tight group-hover:text-blue-600 transition-colors">{alert.title}</span>
                      <span className="text-[10px] font-black text-slate-400 flex items-center mt-1 uppercase tracking-tighter">
                        {alert.alert_type === 'AFRO_NASA_HAZARD' ? (
                          <><Activity className="w-3 h-3 mr-1" /> NASA {alert.hazard}</>
                        ) : (
                          <><span className="font-mono bg-slate-100 px-1 rounded mr-1">{alert.disease?.icd10}</span> {alert.disease?.name || 'Infection'}</>
                        )}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center text-xs font-bold text-slate-500">
                      <MapPin className="w-3.5 h-3.5 text-slate-300 mr-1.5" />
                      {alert.country_iso3} / {alert.admin1}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-xs font-black text-slate-800 tracking-tight">{alert.evidence.signal_count} signals</span>
                      <div className="w-16 h-1 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
                         <div className="h-full bg-blue-500" style={{width: `${alert.confidence * 100}%`}}></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="bg-white border border-slate-200 p-2 rounded-lg text-slate-400 hover:text-blue-600 hover:border-blue-200 shadow-sm transition-all active:scale-95">
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredAlerts.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center text-slate-400">
                    <div className="flex flex-col items-center">
                       <AlertCircle className="w-12 h-12 mb-4 opacity-20" />
                       <p className="text-lg font-black uppercase tracking-tighter">No intelligence matches</p>
                       <p className="text-xs font-bold text-slate-400 mt-1">Try searching by localized disease names or language (e.g. 'Kiswahili')</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {selectedAlert && <AlertDetailModal alert={selectedAlert} onClose={() => setSelectedAlert(null)} />}
    </>
  );
};
