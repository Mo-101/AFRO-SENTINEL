
import React from 'react';
import { Signal, AlertLevel } from '../types';
import { X, ExternalLink, Activity, Skull, MapPin, Calendar, Database, Globe, Tag, ShieldCheck, Radio, Newspaper, Satellite, Shield, User } from 'lucide-react';

interface SignalModalProps {
  signal: Signal | null;
  onClose: () => void;
}

const SignalModal: React.FC<SignalModalProps> = ({ signal, onClose }) => {
  if (!signal) return null;

  const primarySource = signal.sources?.[0];

  const getSourceConfig = (tier: number) => {
    const configs: Record<number, any> = {
      1: { color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', tierLabel: 'High Fidelity / Official', icon: ShieldCheck },
      2: { color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100', tierLabel: 'Verified Field / NGO', icon: Newspaper },
      3: { color: 'text-slate-500', bg: 'bg-slate-100', border: 'border-slate-200', tierLabel: 'Grassroots Signal / Community', icon: Radio },
    };
    return configs[tier] || configs[3];
  };

  const getCategoryIcon = (type: string) => {
    const t = type.toLowerCase();
    if (t.includes('official')) return ShieldCheck;
    if (t.includes('news')) return Newspaper;
    if (t.includes('social') || t.includes('internet')) return Globe;
    if (t.includes('traditional') || t.includes('media')) return Radio;
    if (t.includes('humanitarian')) return Shield;
    if (t.includes('individual') || t.includes('witness')) return User;
    return Satellite;
  };

  const sourceConfig = getSourceConfig(primarySource?.tier || 3);
  const CategoryIcon = getCategoryIcon(primarySource?.type || 'Intelligence');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <div 
        className="bg-white rounded-[2rem] w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]" 
        onClick={e => e.stopPropagation()}
      >
        <div className="p-8 border-b border-slate-100 flex justify-between items-start bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="bg-slate-900 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
                {signal.hazard.name}
              </span>
              <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border ${
                signal.level === AlertLevel.CRITICAL ? 'bg-red-100 text-red-700 border-red-200' : 
                signal.level === AlertLevel.HIGH ? 'bg-orange-100 text-orange-700 border-orange-200' : 
                'bg-blue-100 text-blue-700 border-blue-200'
              }`}>
                {signal.level} Alert
              </span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 leading-tight mb-1">{signal.headline}</h2>
            <div className="flex items-center text-slate-400 text-xs font-bold uppercase tracking-wider gap-3">
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {signal.location.country} ({signal.location.country_iso})</span>
              <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {signal.publishedAt}</span>
            </div>
          </div>
          <button onClick={onClose} className="bg-white p-2 rounded-full shadow-sm border border-slate-200 text-slate-400 hover:text-slate-900 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-8 overflow-y-auto custom-scrollbar space-y-8">
          
          <div className="grid grid-cols-2 gap-4">
             <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-100">
               <div className="flex items-center gap-2 text-emerald-600 mb-2">
                 <Activity className="w-5 h-5" />
                 <span className="text-[10px] font-black uppercase tracking-widest">Suspected Load</span>
               </div>
               <div className="text-3xl font-black text-slate-900">{signal.epi.cases_suspected?.toLocaleString() || 'N/A'}</div>
             </div>
             <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100">
               <div className="flex items-center gap-2 text-slate-500 mb-2">
                 <Skull className="w-5 h-5" />
                 <span className="text-[10px] font-black uppercase tracking-widest">Reported Deaths</span>
               </div>
               <div className="text-3xl font-black text-slate-900">{signal.epi.deaths?.toLocaleString() || '0'}</div>
             </div>
          </div>

          <div className="bg-slate-50 rounded-[1.5rem] p-6 border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-slate-400" />
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Lingua Audit Engine</h3>
              </div>
              {signal.lingua.local_voice && (
                <span className="text-[10px] font-black text-emerald-600 bg-emerald-100/50 px-3 py-1 rounded-full border border-emerald-100">🏠 LOCAL VOICE DETECTED</span>
              )}
            </div>
            
            <div className="space-y-4">
              <div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-1">Source Text ({signal.lingua.original_language_name})</span>
                <p className="text-slate-700 italic font-medium leading-relaxed">"{signal.lingua.original_text}"</p>
              </div>

              {signal.lingua.detected_keywords && signal.lingua.detected_keywords.length > 0 && (
                <div className="flex flex-col gap-2">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <Tag className="w-3 h-3" /> Lingua Markers
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {signal.lingua.detected_keywords.map((kw, idx) => (
                      <span key={idx} className="bg-white border border-slate-200 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="h-px bg-slate-200" />
              
              <div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-1">AI Analytical Translation</span>
                <p className="text-slate-600 font-medium leading-relaxed">{signal.lingua.translation_text || signal.summary}</p>
              </div>
            </div>
          </div>

          <div>
             <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-3 flex items-center gap-2">
               <Database className="w-4 h-4 text-slate-400" />
               Validation & Source Category
             </h3>
             <div className={`p-6 rounded-[2rem] border-2 flex flex-col gap-6 transition-all ${sourceConfig.bg} ${sourceConfig.border}`}>
               <div className="flex items-center justify-between">
                 <div className="flex items-center gap-4">
                   <div className={`w-14 h-14 rounded-2xl bg-white border flex items-center justify-center shadow-sm ${sourceConfig.border}`}>
                     <CategoryIcon className={`w-7 h-7 ${sourceConfig.color}`} />
                   </div>
                   <div>
                     <div className="flex items-center gap-2">
                       <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${sourceConfig.color}`}>{primarySource?.type} Category</span>
                       <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tier {primarySource?.tier || 3} Weight</span>
                     </div>
                     <div className="text-lg font-black text-slate-900 leading-tight">{primarySource?.name}</div>
                   </div>
                 </div>
                 <div className="text-right">
                   <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Reliability</div>
                   <div className={`text-2xl font-black ${sourceConfig.color}`}>T{primarySource?.tier || 3}</div>
                 </div>
               </div>

               <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/70 border border-white rounded-xl p-3 shadow-sm">
                    <span className="text-[8px] font-black text-slate-400 uppercase block mb-1.5">Weight Description</span>
                    <div className="text-[10px] font-black text-slate-700 uppercase mb-2">{sourceConfig.tierLabel}</div>
                    <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                       <div className={`h-full rounded-full ${sourceConfig.color.replace('text-', 'bg-')}`} style={{ width: primarySource?.tier === 1 ? '100%' : primarySource?.tier === 2 ? '65%' : '35%' }}></div>
                    </div>
                  </div>
                  <div className="bg-white/70 border border-white rounded-xl p-3 shadow-sm">
                    <span className="text-[8px] font-black text-slate-400 uppercase block mb-1">Signal Fidelity</span>
                    <div className="text-sm font-black text-slate-900 mt-1">{(signal.confidence * 100).toFixed(0)}% Probability</div>
                    <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Cross-Verificaton Active</p>
                  </div>
               </div>

               {primarySource?.url && (
                 <a 
                   href={primarySource.url} 
                   target="_blank" 
                   rel="noreferrer" 
                   className={`flex items-center justify-center gap-2 p-3.5 rounded-xl border font-black text-[10px] uppercase tracking-widest transition-all bg-white hover:shadow-xl ${sourceConfig.border} ${sourceConfig.color} active:scale-[0.98]`}
                 >
                   Open Raw Intelligence Source <ExternalLink className="w-3.5 h-3.5" />
                 </a>
               )}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignalModal;
