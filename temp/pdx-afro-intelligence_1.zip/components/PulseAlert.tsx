
import React, { useState, useEffect } from 'react';
import { Signal, AlertLevel } from '../types';
import { MapPin, Globe, ShieldAlert } from 'lucide-react';

interface PulseAlertProps {
  signal: Signal;
  index: number;
  onClose: (id: string) => void;
  onClick: (s: Signal) => void;
}

const PRIORITY_THEME = {
  [AlertLevel.CRITICAL]: { border: 'border-red-500', icon: '🔴', glow: 'shadow-red-200' },
  [AlertLevel.HIGH]: { border: 'border-orange-500', icon: '🟠', glow: 'shadow-orange-100' },
  [AlertLevel.MEDIUM]: { border: 'border-amber-500', icon: '🟡', glow: 'shadow-amber-100' },
  [AlertLevel.LOW]: { border: 'border-emerald-500', icon: '🟢', glow: 'shadow-emerald-500' },
};

export const PulseAlert: React.FC<PulseAlertProps> = ({ signal, index, onClose, onClick }) => {
  const [visible, setVisible] = useState(false);
  const theme = PRIORITY_THEME[signal.level] || PRIORITY_THEME[AlertLevel.LOW];

  useEffect(() => {
    const showTimer = setTimeout(() => setVisible(true), 50);
    const hideTimer = setTimeout(() => {
      setVisible(false);
      setTimeout(() => onClose(signal.id), 500);
    }, 8000);
    return () => { clearTimeout(showTimer); clearTimeout(hideTimer); };
  }, [signal.id, onClose]);

  return (
    <div
      onClick={() => { onClick(signal); onClose(signal.id); }}
      className={`fixed right-6 z-[100] w-80 p-4 rounded-2xl bg-white shadow-2xl border-l-4 ${theme.border} cursor-pointer transition-all duration-500 transform ${visible ? 'translate-x-0 opacity-100' : 'translate-x-[400px] opacity-0'}`}
      style={{ bottom: `${24 + (index * 160)}px` }}
    >
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center gap-2">
          <span className="text-lg">{theme.icon}</span>
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-900">{signal.hazard?.name || 'Unknown'}</span>
        </div>
        <span className="text-[9px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full">{signal.human_readable_time}</span>
      </div>

      <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 mb-3">
        <MapPin className="w-3 h-3" />
        <span>{signal.location?.country || 'Unknown'} {signal.location?.admin1 ? `· ${signal.location.admin1}` : ''}</span>
      </div>

      <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 mb-2">
        <div className="flex items-center gap-1.5 mb-1">
          <Globe className="w-3 h-3 text-slate-400" />
          <span className="text-[9px] font-black text-slate-400 uppercase">{signal.lingua?.original_language_name || 'English'}</span>
        </div>
        <p className="text-[11px] text-slate-600 font-medium italic line-clamp-2 leading-relaxed">
          "{signal.lingua?.original_text || 'No snippet available'}"
        </p>
      </div>

      <div className="flex justify-between items-center pt-2 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <span className="text-xs">{signal.sources?.[0]?.icon || '📡'}</span>
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-tight">{signal.sources?.[0]?.name || 'Sentinel'}</span>
        </div>
        {signal.lingua?.local_voice && (
          <span className="text-[8px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">🏠 LOCAL VOICE</span>
        )}
      </div>
    </div>
  );
};
