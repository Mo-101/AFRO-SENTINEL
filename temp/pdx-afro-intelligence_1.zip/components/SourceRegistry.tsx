import React from 'react';
import { ApiSource } from '../types';
import { CheckCircle2, AlertOctagon, RefreshCw, Server, Lock, Globe } from 'lucide-react';

interface SourceRegistryProps {
  sources: ApiSource[];
}

export const SourceRegistry: React.FC<SourceRegistryProps> = ({ sources }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sources.map((source) => (
        <div key={source.source_id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col h-full">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2.5 bg-blue-50 rounded-lg text-blue-600">
              <Server className="w-6 h-6" />
            </div>
            <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center ${
              source.status === 'active' 
                ? 'bg-emerald-100 text-emerald-800' 
                : 'bg-yellow-100 text-yellow-800'
            }`}>
              {source.status === 'active' ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <AlertOctagon className="w-3 h-3 mr-1" />}
              {source.status.toUpperCase()}
            </span>
          </div>
          
          <h3 className="text-lg font-bold text-slate-900">{source.source_name}</h3>
          <p className="text-sm font-mono text-slate-400 mt-1 mb-4">{source.source_id}</p>
          
          <div className="space-y-3 flex-1">
            <div className="flex items-center text-sm text-slate-600">
              <Globe className="w-4 h-4 mr-2 text-slate-400" />
              <span className="truncate">{source.base_url}</span>
            </div>
            <div className="flex items-center text-sm text-slate-600">
               <span className="w-20 text-slate-400 text-xs uppercase font-semibold">Type</span>
               <span className="bg-slate-100 px-2 py-0.5 rounded text-xs border border-slate-200">{source.source_type}</span>
            </div>
             <div className="flex items-center text-sm text-slate-600">
               <span className="w-20 text-slate-400 text-xs uppercase font-semibold">Coverage</span>
               <span>{source.coverage}</span>
            </div>
             <div className="flex items-center text-sm text-slate-600">
               <span className="w-20 text-slate-400 text-xs uppercase font-semibold">Priority</span>
               <div className="flex gap-0.5">
                 {[1, 2, 3].map(i => (
                   <div key={i} className={`h-2 w-2 rounded-full ${i <= source.priority ? 'bg-blue-600' : 'bg-slate-200'}`} />
                 ))}
               </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between items-center">
            <div className="flex items-center text-xs text-slate-400">
              <RefreshCw className="w-3 h-3 mr-1" />
              Auto-pull active
            </div>
            <button className="text-xs font-medium text-blue-600 hover:text-blue-800">
              Config
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};