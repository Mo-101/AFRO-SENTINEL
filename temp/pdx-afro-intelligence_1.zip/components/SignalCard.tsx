
import React from 'react';
import { Signal, AlertLevel } from '../types';
import { ShieldCheck, FileText, AlertTriangle, Shield, Newspaper, Radio, Satellite, Globe, User } from 'lucide-react';

interface SignalCardProps {
  signal: Signal;
  onClick: (s: Signal) => void;
}

const SignalCard: React.FC<SignalCardProps> = ({ signal, onClick }) => {
  const getBorderColor = (level: AlertLevel) => {
    switch (level) {
      case AlertLevel.CRITICAL: return 'border-red-500 bg-red-50/10 hover:border-red-600';
      case AlertLevel.HIGH: return 'border-orange-400 bg-orange-50/10 hover:border-orange-500';
      case AlertLevel.MEDIUM: return 'border-amber-400 bg-amber-50/10 hover:border-amber-500';
      default: return 'border-slate-200 hover:border-blue-400';
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return 'bg-emerald-500';
    if (score >= 0.5) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const primarySource = signal.sources?.[0];

  const getTierMeta = (tier: number) => {
    if (tier === 1) return { label: 'High Fidelity', color: 'text-emerald-600 bg-emerald-50 border-emerald-100', icon: ShieldCheck };
    if (tier === 2) return { label: 'Verified Field', color: 'text-blue-600 bg-blue-50 border-blue-100', icon: Newspaper };
    return { label: 'Grassroots', color: 'text-slate-500 bg-slate-50 border-slate-200', icon: Radio };
  };

  const getCategoryIcon = (type: string) => {
    const t = type.toLowerCase();
    if (t.includes('official')) return ShieldCheck;
    if (t.includes('news')) return Newspaper;
    if (t.includes('social') || t.includes('internet')) return Globe;
    if (t.includes('traditional') || t.includes('media')) return Radio;
    if (t.includes('humanitarian')) return Shield;
    if (t.includes('individual') || t.includes('witness')) return User;
    return Satellite;
  };

  const tierMeta = getTierMeta(primarySource?.tier || 3);
  const CategoryIcon = getCategoryIcon(primarySource?.type || 'Intelligence');

  return (
    <div 
      onClick={() => onClick(signal)}
      className={`relative bg-white p-6 rounded-[2rem] border-2 transition-all cursor-pointer hover:shadow-xl hover:-translate-y-1 flex flex-col h-full group ${getBorderColor(signal.level)}`}
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-2">
          <span className="bg-slate-900 text-white text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest">
            {signal.hazard?.name || 'Unknown Hazard'}
          </span>
          {signal.lingua?.local_voice && (
            <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 uppercase tracking-tighter">🏠 LOCAL VOICE</span>
          )}
        </div>
        <span className="text-[10px] font-black text-slate-400 uppercase flex items-center gap-1">
          {signal.level === AlertLevel.CRITICAL && <AlertTriangle className="w-3 h-3 text-red-500" />}
          {signal.publishedAt}
        </span>
      </div>

      <h4 className="text-lg font-black text-slate-900 leading-tight mb-2 group-hover:text-blue-600 transition-colors line-clamp-2">
        {signal.headline}
      </h4>
      
      <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100 mb-4">
        <div className="text-[8px] font-black text-slate-400 uppercase mb-1 tracking-widest">{signal.lingua?.original_language_name || 'English'} Transcription</div>
        <p className="text-[11px] text-slate-500 font-medium italic line-clamp-2 leading-relaxed">"{signal.lingua?.original_text || 'Monitoring...'}"</p>
      </div>

      <p className="text-xs text-slate-500 font-medium leading-relaxed mb-6 line-clamp-3 flex-1">
        {signal.summary}
      </p>

      {/* Structured Source Attribution Layer */}
      <div className="mb-4 space-y-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[8px] font-black uppercase tracking-[0.1em] ${tierMeta.color}`}>
            <CategoryIcon className="w-3 h-3" />
            {primarySource?.type || 'Source Category'}
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg border border-slate-900 bg-slate-900 text-white text-[8px] font-black uppercase tracking-[0.1em]">
             Tier {primarySource?.tier || 3} RELIABILITY
          </div>
        </div>
        <div className="flex items-center gap-2 px-1">
          <div className="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
          <span className="text-[10px] font-bold text-slate-600 truncate">{primarySource?.name}</span>
        </div>
      </div>

      <div className="mt-auto flex items-center justify-between pt-4 border-t border-slate-100">
        <div className="flex items-center gap-3">
           <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center">
             <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
           </div>
           <div className="flex flex-col">
             <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Confidence Score</span>
             <div className="flex items-center gap-1.5">
                <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                   <div className={`h-full rounded-full ${getConfidenceColor(signal.confidence)}`} style={{width: `${signal.confidence * 100}%`}}></div>
                </div>
                <span className="text-[9px] font-black text-slate-900">{(signal.confidence * 100).toFixed(0)}%</span>
             </div>
           </div>
        </div>
        <button className="text-slate-400 hover:text-slate-900 transition-all hover:scale-110 active:scale-95">
          <FileText className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default SignalCard;
