
export enum AlertLevel {
  LOW = 'P4',
  MEDIUM = 'P3',
  HIGH = 'P2',
  CRITICAL = 'P1'
}

export type SeverityLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface Country {
  code: string;
  name: string;
  region: string;
}

export interface Disease {
  code: string;
  name: string;
  syndrome: string;
}

export interface ApiSource {
  source_id: string;
  source_name: string;
  status: 'active' | 'inactive';
  base_url: string;
  documentation_url?: string;
  source_type: string;
  category: string;
  coverage: string;
  priority: number;
  auth_type: string;
  data_format: string;
}

export interface ExpandedApiSource extends ApiSource {}

export interface PDXAlert {
  alert_id: string;
  title: string;
  summary: string;
  alert_level: AlertLevel;
  severity: SeverityLevel;
  country_iso3: string;
  admin1: string;
  created_at: string;
  confidence: number;
  source_link?: string;
  keywords?: Record<string, string[]>;
  hazard?: string;
  disease?: {
    icd10: string;
    name: string;
  };
  evidence: {
    unique_sources: number;
    signal_count: number;
  };
  alert_type: string;
}

export interface LinguaData {
  original_text: string;
  original_language_code: string;
  original_language_name: string;
  translation_text?: string;
  local_voice: boolean;
  language_location_match: boolean;
  detected_keywords?: string[];
}

export interface EpidemiologyData {
  cases_suspected?: number;
  cases_confirmed?: number;
  deaths?: number;
  cfr_observed?: number;
}

export interface Signal {
  id: string;
  signal_id: string;
  headline: string;
  summary: string;
  publishedAt: string;
  human_readable_time: string;
  level: AlertLevel;
  confidence: number;
  
  hazard: {
    type: 'disease' | 'climate' | 'health_system';
    name: string;
    category: string;
    who_afro_code: string;
  };
  
  location: {
    country: string;
    country_iso: string;
    admin1?: string;
  };
  
  epi: EpidemiologyData;
  lingua: LinguaData;
  
  sources: {
    tier: 1 | 2 | 3;
    type: string;
    name: string;
    icon: string;
    url?: string;
  }[];
  
  tags: string[];
}

export interface RegionalSummary {
  disease: string;
  trend: 'increasing' | 'decreasing' | 'stable';
  countriesAffected: number;
  countriesList: string[];
  totalEstimatedCases: number;
}

export interface BackendSignal {
  id: string;
  timestamp: string;
  type: 'heartbeat' | 'data_packet';
  status: 'ok' | 'latency';
}

export interface AutoDetection {
  id: string;
  type: 'ANOMALY_DETECTED' | 'VIRAL_SURGE';
  severity: 'HIGH' | 'CRITICAL';
  title: string;
  description: string;
  location: string;
  metric: string;
}
