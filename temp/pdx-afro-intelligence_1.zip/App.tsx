
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Sidebar from './components/Sidebar';
import SignalCard from './components/SignalCard';
import SignalModal from './components/SignalModal';
import { RecentSignals } from './components/RecentSignals';
import { AutoDetectionPopup } from './components/AutoDetectionPopup';
import { PulseAlert } from './components/PulseAlert';
import { AdvancedFilters } from './components/AdvancedFilters';
import { Signal, AlertLevel, RegionalSummary, AutoDetection } from './types';
import { fetchLiveSignals, fetchRegionalIntelligence, fetchRegionalSignals } from './services/azureService';
import { fetchAutoDetections } from './services/backendService';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const PanoramaCard: React.FC<{ item: RegionalSummary }> = ({ item }) => {
  const trendColor = item.trend === 'increasing' ? 'text-red-500' : item.trend === 'decreasing' ? 'text-emerald-500' : 'text-amber-500';
  
  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-500 transition-colors flex flex-col justify-between min-h-[140px] group">
      <div className="flex justify-between items-start mb-2">
        <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight group-hover:text-emerald-600 transition-colors">{item.disease}</h4>
        <div className={`flex items-center gap-1.5 text-[10px] font-black ${trendColor} uppercase`}>
          <span>{item.trend}</span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div>
          <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">Countries</p>
          <p className="text-xl font-black text-slate-800">{item.countriesAffected}</p>
        </div>
        <div>
          <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">Est. Cases</p>
          <p className="text-xl font-black text-emerald-600">{item.totalEstimatedCases?.toLocaleString() || '0'}</p>
        </div>
      </div>
      <p className="text-[9px] text-slate-500 font-bold truncate border-t border-slate-50 pt-2">
        {item.countriesList?.join(', ') || 'Scanning hotspots...'}
      </p>
    </div>
  );
};

const TrafficLightHeatmap = ({ items }: { items: RegionalSummary[] }) => {
  if (items.length === 0) return (
    <div className="py-12 text-center text-slate-500 text-[10px] font-black uppercase tracking-widest animate-pulse">Scanning Pathogen Load...</div>
  );
  
  return (
    <div className="space-y-5 flex-1 overflow-y-auto custom-scrollbar pr-2">
      {items.map((item) => {
        let bgColor = "bg-emerald-500";
        let dotColor = "bg-emerald-400";
        let statusText = "Stable";

        if (item.trend === 'increasing' || item.countriesAffected > 5) {
          bgColor = "bg-red-500";
          dotColor = "bg-red-400";
          statusText = "Critical";
        } else if (item.countriesAffected > 2) {
          bgColor = "bg-amber-500";
          dotColor = "bg-amber-400";
          statusText = "Alert";
        }

        return (
          <div key={item.disease} className="group cursor-default">
            <div className="flex justify-between items-end text-[10px] font-black uppercase mb-1.5">
              <div className="flex items-center gap-2">
                <span className={`w-1.5 h-1.5 rounded-full ${dotColor} animate-pulse`}></span>
                <span className="text-slate-400 tracking-tight group-hover:text-white transition-colors">{item.disease}</span>
              </div>
              <span className={bgColor.replace('bg-', 'text-')}>{statusText}</span>
            </div>
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700 relative shadow-inner">
              <div 
                className={`h-full ${bgColor} rounded-full transition-all duration-1000 ease-out shadow-sm`}
                style={{ width: `${Math.min(100, (item.countriesAffected / 47) * 500)}%` }}
              ></div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const LiveTicker = ({ signals, regionalData }: { signals: Signal[], regionalData: RegionalSummary[] }) => {
  const tickerItems = useMemo(() => {
    const list: string[] = [];
    if (regionalData && regionalData.length > 0) {
      regionalData.forEach(r => list.push(`REGIONAL HAZARD: ${r.disease} across ${r.countriesAffected} countries... TREND: ${r.trend.toUpperCase()}...`));
    }
    if (signals && signals.length > 0) {
      signals.slice(0, 15).forEach(s => {
        const country = s.location?.country?.toUpperCase() || 'UNKNOWN';
        const headline = s.headline?.toUpperCase() || 'UNTITLED SIGNAL';
        list.push(`SIGNAL (${country}): ${headline}... STATUS: ${s.level || 'P4'}...`);
      });
    }
    return list;
  }, [signals, regionalData]);

  if (tickerItems.length === 0) return null;

  return (
    <div className="bg-slate-900 overflow-hidden relative border-y border-slate-800 py-2.5 shadow-2xl z-10 shrink-0">
      <div className="absolute left-0 top-0 bottom-0 bg-slate-900 px-5 flex items-center border-r border-slate-800 z-20">
        <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          Live AFRO Intelligence
        </span>
      </div>
      <div className="whitespace-nowrap flex items-center gap-20 pl-48 animate-[marquee_60s_linear_infinite]">
        {[...tickerItems, ...tickerItems].map((text, idx) => (
          <div key={idx} className="flex items-center gap-6 shrink-0">
            <span className="text-[11px] font-bold text-slate-300 tracking-tight italic">{text}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-700"></span>
          </div>
        ))}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [selectedCountry, setSelectedCountry] = useState('AFRO Regional Panorama');
  const [signals, setSignals] = useState<Signal[]>([]);
  const [floatingAlerts, setFloatingAlerts] = useState<Signal[]>([]);
  const [detections, setDetections] = useState<AutoDetection[]>([]);
  const [regionalPanorama, setRegionalPanorama] = useState<RegionalSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [filterLevel, setFilterLevel] = useState<string>('ALL');
  const [activeSignal, setActiveSignal] = useState<Signal | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [simulatedCount, setSimulatedCount] = useState(14582);
  const [isRateLimited, setIsRateLimited] = useState(false);

  const isRegional = selectedCountry === 'AFRO Regional Panorama';
  const autoRefreshTimer = useRef<number | null>(null);

  const loadAllIntelligence = useCallback(async (location: string, isSilent = false) => {
    if (!isSilent) setLoading(true);
    setErrorMsg(null);
    setIsRateLimited(false);

    try {
      if (location === 'AFRO Regional Panorama') {
        const [regionalSummary, regionalSignals, bDetections] = await Promise.all([
          fetchRegionalIntelligence(),
          fetchRegionalSignals(),
          fetchAutoDetections()
        ]);
        setRegionalPanorama(regionalSummary || []);
        setSignals(regionalSignals || []);
        setDetections(bDetections || []);
        
        if (regionalSignals && regionalSignals.length > 0) {
          setFloatingAlerts(prev => {
            const existingIds = new Set(prev.map(a => a.id));
            const newOnes = regionalSignals.filter(s => !existingIds.has(s.id)).slice(0, 1);
            return [...prev, ...newOnes].slice(-5);
          });
        }
      } else {
        const [localData, bDetections] = await Promise.all([
          fetchLiveSignals(location),
          fetchAutoDetections()
        ]);
        setSignals(localData || []);
        setDetections(bDetections || []);
        if (localData && localData.length > 0) {
          setFloatingAlerts(prev => {
            const existingIds = new Set(prev.map(a => a.id));
            const newOnes = localData.filter(s => !existingIds.has(s.id)).slice(0, 1);
            return [...prev, ...newOnes].slice(-5);
          });
        }
        fetchRegionalIntelligence().then(setRegionalPanorama);
      }
    } catch (error: any) {
      console.error("Critical Surveillance Outage:", error);
      if (error?.message?.includes('429')) {
        setIsRateLimited(true);
        setErrorMsg("Quota Exhausted. System cooling down for 60s...");
        setTimeout(() => setErrorMsg(null), 10000);
      } else {
        setErrorMsg("Intelligence Grid Interrupted. Retrying Node Connection...");
      }
    } finally {
      if (!isSilent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllIntelligence(selectedCountry);
    
    // Auto-refresh frequency reduced to 2 minutes to respect quotas
    if (autoRefreshTimer.current) clearInterval(autoRefreshTimer.current);
    autoRefreshTimer.current = window.setInterval(() => {
      loadAllIntelligence(selectedCountry, true);
    }, 120000);

    // Dynamic Simulated Count Pulse remains to keep UI alive
    const pulseTimer = setInterval(() => {
      setSimulatedCount(prev => prev + Math.floor(Math.random() * 3));
    }, 5000);

    return () => {
      if (autoRefreshTimer.current) clearInterval(autoRefreshTimer.current);
      clearInterval(pulseTimer);
    };
  }, [selectedCountry, loadAllIntelligence]);

  const stats = useMemo(() => {
    return {
      totalSignals: signals.length,
      activeOutbreaks: isRegional ? regionalPanorama.length : (signals.length > 0 ? 1 : 0),
      criticalAlerts: signals.filter(s => s.level === AlertLevel.CRITICAL).length,
      countriesMonitoring: isRegional ? 47 : 1
    };
  }, [signals, regionalPanorama, isRegional]);

  const signalCountsByLevel = useMemo(() => {
    const counts: Record<string, number> = {};
    signals.forEach(s => {
      counts[s.level] = (counts[s.level] || 0) + 1;
    });
    return counts;
  }, [signals]);

  const filteredSignals = useMemo(() => {
    if (filterLevel === 'ALL') return signals;
    return signals.filter(s => s.level === filterLevel);
  }, [signals, filterLevel]);

  const chartData = useMemo(() => {
    return signals
      .map(s => ({
        name: s.publishedAt,
        cases: s.epi?.cases_suspected || 0
      }))
      .sort((a, b) => new Date(a.name).getTime() - new Date(b.name).getTime());
  }, [signals]);

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-inter">
      <Sidebar
        selectedCountry={selectedCountry}
        onSelectCountry={setSelectedCountry}
      >
        <AdvancedFilters 
          signalCounts={signalCountsByLevel} 
          onFilterChange={(f) => console.log('Filters:', f)} 
        />
      </Sidebar>
      
      <main className="flex-1 overflow-y-auto min-w-0 flex flex-col custom-scrollbar relative">
        {errorMsg && (
            <div className={`text-white text-center py-2 text-xs font-bold uppercase tracking-widest z-50 animate-pulse ${isRateLimited ? 'bg-amber-600' : 'bg-red-600'}`}>
                {errorMsg}
            </div>
        )}
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 px-8 py-5 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full animate-ping opacity-75 ${isRateLimited ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
              <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${isRateLimited ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tighter uppercase leading-none">{selectedCountry}</h2>
            </div>
            <div className="hidden sm:flex flex-col ml-4 border-l border-slate-200 pl-4">
              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Global Sync</span>
              <span className={`text-[11px] font-black uppercase ${isRateLimited ? 'text-amber-600' : 'text-emerald-600 animate-pulse'}`}>
                {isRateLimited ? 'QUOTA LIMIT ACTIVE' : 'LIVE DATA FLOWING'}
              </span>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200">
              {['ALL', 'P1', 'P2', 'P3'].map(lvl => (
                <button
                  key={lvl}
                  onClick={() => setFilterLevel(lvl === 'ALL' ? 'ALL' : lvl as AlertLevel)}
                  className={`px-3 py-1.5 text-[10px] font-black rounded-md transition-all ${
                    filterLevel === lvl 
                    ? 'bg-white text-slate-900 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
            <button 
              onClick={() => loadAllIntelligence(selectedCountry)}
              disabled={loading || isRateLimited}
              className="px-5 py-2.5 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-black tracking-widest uppercase transition-all flex items-center gap-2 shadow-lg shadow-slate-900/10 active:scale-95 disabled:opacity-50"
            >
              {loading ? 'SYNCING...' : isRateLimited ? 'COOLING DOWN' : 'Force Sync'}
            </button>
          </div>
        </header>

        <div className="p-8 space-y-10 max-w-[1600px] mx-auto w-full flex-1 pb-20">
          
          {isRegional && (
            <section className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="bg-slate-900 text-emerald-400 w-10 h-10 rounded-xl flex items-center justify-center shadow-md">
                   <span className="text-xl">📡</span>
                </div>
                <div>
                  <h3 className="font-black text-slate-900 uppercase tracking-tighter text-xl">Regional Hazard Panorama</h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Live Synthesis (47 States)</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
                {(loading && regionalPanorama.length === 0) ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="bg-white rounded-2xl h-36 animate-pulse border border-slate-100 shadow-sm"></div>
                  ))
                ) : regionalPanorama.map((item, idx) => (
                  <PanoramaCard key={idx} item={item} />
                ))}
              </div>
            </section>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Signals Processed', val: simulatedCount.toLocaleString(), color: 'text-slate-900', bg: 'bg-emerald-50', pulse: !isRateLimited },
              { label: 'Active Hazards', val: stats.activeOutbreaks, color: 'text-amber-600', bg: 'bg-amber-50' },
              { label: 'Critical Alerts', val: stats.criticalAlerts, color: 'text-red-600', bg: 'bg-red-50' },
              { label: 'Scope (States)', val: stats.countriesMonitoring, color: 'text-blue-600', bg: 'bg-blue-50' }
            ].map((box, i) => (
              <div key={i} className="bg-white p-7 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group relative overflow-hidden">
                <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 ${box.bg} rounded-full group-hover:scale-110 transition-transform`}></div>
                <div className="text-slate-400 text-[10px] font-black uppercase mb-3 tracking-widest relative flex items-center gap-2">
                  {box.pulse && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>}
                  {box.label}
                </div>
                <div className={`text-4xl font-black ${box.color} relative tracking-tighter transition-all duration-300`}>
                  {(loading && signals.length === 0) ? '...' : box.val}
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm min-h-[500px] flex flex-col">
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h3 className="font-black text-slate-900 text-2xl uppercase tracking-tighter leading-none">
                    {isRegional ? 'AFRO' : selectedCountry} Intensity Trend
                  </h3>
                  <p className="text-[10px] text-slate-500 font-black mt-2 uppercase tracking-widest">Temporal Frequency Load · Auto-Updating</p>
                </div>
              </div>
              <div className="flex-1 w-full min-h-[400px]">
                {chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={400}>
                    <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorCases" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="#f1f5f9" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fontSize: 9, fill: '#94a3b8', fontWeight: 900}} 
                        tickFormatter={(val) => val ? new Date(val).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }).toUpperCase() : ''}
                      />
                      <YAxis axisLine={false} tickLine={false} tick={{fontSize: 9, fill: '#94a3b8', fontWeight: 900}} />
                      <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontSize: '10px', fontWeight: 'bold' }} />
                      <Area 
                        type="monotone" 
                        dataKey="cases" 
                        stroke="#10b981" 
                        strokeWidth={4} 
                        fillOpacity={1} 
                        fill="url(#colorCases)" 
                        animationDuration={1500}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-400 space-y-4 h-full">
                    <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center">
                       <span className="text-xl opacity-30">📈</span>
                    </div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-center animate-pulse">
                      {loading ? 'Negotiating neural links...' : 'Zero temporal load detected'}
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-slate-900 p-10 rounded-[2.5rem] shadow-2xl flex flex-col h-[500px]">
              <h3 className="font-black text-white text-xl mb-8 uppercase tracking-tighter">
                Priority Heatmap
              </h3>
              <TrafficLightHeatmap items={isRegional ? (regionalPanorama || []) : []} />
              {!isRegional && (
                 <div className="flex-1 flex flex-col items-center justify-center text-slate-600 space-y-4 px-6 text-center">
                    <span className="text-2xl animate-pulse">📡</span>
                    <p className="text-[10px] font-black uppercase tracking-widest leading-loose">
                      Syncing Local Node with regional models...
                    </p>
                 </div>
              )}
              <div className="mt-auto pt-6 border-t border-slate-800">
                <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700/50">
                  <div className="flex justify-between items-center mb-1.5">
                    <p className="text-[10px] text-emerald-400 font-black uppercase tracking-widest">Logic Layer</p>
                    <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${isRateLimited ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-relaxed font-bold uppercase tracking-tighter">
                    {isRateLimited ? 'Throttled data flow to preserve system quota.' : 'Reflects real-time pathogen velocity and spread metrics.'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="-mx-8 shrink-0">
            <LiveTicker signals={signals} regionalData={regionalPanorama} />
          </div>

          <div>
             <div className="flex items-center gap-5 mb-10">
                <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center shadow-xl shadow-slate-300 relative">
                  <span className="text-emerald-400 text-xl">🗼</span>
                  <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-white animate-bounce ${isRateLimited ? 'bg-amber-500' : 'bg-red-500'}`}></div>
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-3xl uppercase tracking-tighter leading-none">Intelligence Feed</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <p className="text-[11px] text-slate-500 font-black uppercase tracking-widest leading-none">Node: {selectedCountry}</p>
                    <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                    <span className={`text-[11px] font-black uppercase tracking-widest leading-none ${isRateLimited ? 'text-amber-600' : 'text-emerald-600 animate-pulse'}`}>
                      {isRateLimited ? 'System Cooling Down...' : 'Monitoring Streams...'}
                    </span>
                  </div>
                </div>
              </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {(loading && filteredSignals.length === 0) ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-[2rem] h-[340px] animate-pulse border border-slate-100 shadow-sm"></div>
                ))
              ) : filteredSignals.length > 0 ? (
                filteredSignals.map((sig) => (
                  <SignalCard 
                    key={sig.id} 
                    signal={sig} 
                    onClick={setActiveSignal}
                  />
                ))
              ) : (
                <div className="col-span-full py-32 bg-white border-2 border-dashed border-slate-200 rounded-[3rem] flex flex-col items-center text-center px-10">
                  <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mb-8">
                     <span className="text-4xl text-slate-200">🛰️</span>
                  </div>
                  <h4 className="text-slate-900 font-black text-2xl uppercase tracking-tight">Sector Clean</h4>
                  <p className="text-slate-500 font-bold text-xs uppercase tracking-widest mt-4 max-w-md leading-relaxed">
                    Zero active threats detected in this sector at this temporal window.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <RecentSignals 
        signals={signals} 
        isLoading={loading} 
        onSignalClick={setActiveSignal} 
      />

      {detections && detections.length > 0 && <AutoDetectionPopup detections={detections} />}

      <SignalModal 
        signal={activeSignal} 
        onClose={() => setActiveSignal(null)} 
      />

      <div className="fixed bottom-0 right-0 pointer-events-none flex flex-col items-end gap-3 z-[60] p-6 w-full max-w-md h-full justify-end overflow-hidden">
        {floatingAlerts.map((alert, idx) => (
          <PulseAlert 
            key={alert.id} 
            signal={alert} 
            index={idx} 
            onClose={(id) => setFloatingAlerts(prev => prev.filter(a => a.id !== id))}
            onClick={setActiveSignal}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
