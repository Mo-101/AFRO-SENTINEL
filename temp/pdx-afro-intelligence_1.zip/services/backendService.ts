import { BackendSignal, AutoDetection } from '../types';

export const fetchBackendSignals = async (count: number = 5): Promise<BackendSignal[]> => {
  // Simulate network latency
  await new Promise(r => setTimeout(r, 300));
  
  return Array.from({ length: count }).map((_, i) => ({
    id: `NET-${Date.now()}-${i}`,
    timestamp: new Date().toISOString(),
    type: Math.random() > 0.8 ? 'data_packet' : 'heartbeat',
    status: Math.random() > 0.95 ? 'latency' : 'ok'
  }));
};

export const fetchAutoDetections = async (): Promise<AutoDetection[]> => {
  // Simulate AI detections running in background
  if (Math.random() > 0.7) {
    return [{
      id: `DET-${Date.now()}`,
      type: Math.random() > 0.5 ? 'ANOMALY_DETECTED' : 'VIRAL_SURGE',
      severity: Math.random() > 0.5 ? 'CRITICAL' : 'HIGH',
      title: 'Statistical Anomaly Detected',
      description: 'Unusual spike in respiratory syndrome reports reported by sentinel sites.',
      location: 'Regional Hub East',
      metric: '+450% vs Baseline'
    }];
  }
  return [];
};
