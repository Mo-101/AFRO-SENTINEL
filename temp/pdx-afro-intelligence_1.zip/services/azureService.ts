
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Signal, AlertLevel, RegionalSummary } from '../types';

// Initialize the Gemini API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Simple memory cache to prevent rapid duplicate requests
const INTEL_CACHE: Record<string, { data: any, timestamp: number }> = {};
const CACHE_TTL = 60000; // 60 seconds

/**
 * Utility: Exponential Backoff Wrapper for Gemini API
 */
async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const isRateLimit = error?.message?.includes('429') || error?.status === 429 || error?.error?.code === 429;
    if (isRateLimit && retries > 0) {
      console.warn(`Rate limit hit. Retrying in ${delay}ms... (${retries} left)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

/**
 * DEEP ANALYSIS: Fetches signals using Gemini 3 Pro with thinking mode.
 */
export const fetchLiveSignals = async (location: string): Promise<Signal[]> => {
  const cacheKey = `signals_${location}`;
  if (INTEL_CACHE[cacheKey] && Date.now() - INTEL_CACHE[cacheKey].timestamp < CACHE_TTL) {
    return INTEL_CACHE[cacheKey].data;
  }

  try {
    const data = await withRetry(async () => {
      // Explicitly type response as GenerateContentResponse to ensure .text property is accessible
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `
          You are the AFRO SENTINEL WATCHTOWER Intelligence Analyst.
          Hunt for disease signals and health hazards in ${location} from the last 14 days.
          
          MISSION: Detect EVERYTHING. Prioritize grassroots signals and multilingual detection.
          AFRO LINGUISTIC HAZARD DICTIONARY:
          - CHOLERA: "Kipindupindu" (SW), "Kwalara" (HA), "Choléra" (FR).
          - MALARIA: "Homa ya malaria" (SW), "Zazzabin cizon sauro" (HA).
          - EBOLA: "Homa ya kutokwa na damu" (SW), "Zazzabin jini" (HA).
          
          Return a JSON array of signals. 
          Note: "priority" maps to: P1=CRITICAL, P2=HIGH, P3=MEDIUM, P4=LOW.
        `,
        config: {
          thinkingConfig: { thinkingBudget: 16384 }, // Reduced slightly for efficiency
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                signal_id: { type: Type.STRING },
                headline: { type: Type.STRING },
                summary: { type: Type.STRING },
                priority: { type: Type.STRING, description: "P1, P2, P3, or P4" },
                confidence_score: { type: Type.NUMBER },
                hazard: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    category: { type: Type.STRING },
                    who_afro_code: { type: Type.STRING },
                    type: { type: Type.STRING }
                  }
                },
                location: {
                  type: Type.OBJECT,
                  properties: {
                    country: { type: Type.STRING },
                    country_iso: { type: Type.STRING },
                    admin1: { type: Type.STRING }
                  }
                },
                epi: {
                  type: Type.OBJECT,
                  properties: {
                    cases_suspected: { type: Type.NUMBER },
                    deaths: { type: Type.NUMBER }
                  }
                },
                lingua: {
                  type: Type.OBJECT,
                  properties: {
                    original_text: { type: Type.STRING },
                    original_language_name: { type: Type.STRING },
                    translation_text: { type: Type.STRING },
                    local_voice: { type: Type.BOOLEAN },
                    detected_keywords: { 
                      type: Type.ARRAY, 
                      items: { type: Type.STRING }
                    }
                  }
                },
                sources: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      type: { type: Type.STRING },
                      tier: { type: Type.NUMBER },
                      icon: { type: Type.STRING }
                    }
                  }
                }
              }
            }
          }
        },
      });

      const text = response.text;
      if (!text) return [];
      
      const raw = JSON.parse(text);
      return raw.map((s: any, i: number) => {
        const signalId = s.signal_id || `SIG-${Date.now()}-${i}`;
        return {
          ...s,
          id: signalId,
          signal_id: signalId,
          level: (s.priority as AlertLevel) || AlertLevel.LOW,
          confidence: s.confidence_score || 0.8,
          publishedAt: new Date().toISOString().split('T')[0],
          human_readable_time: 'just now',
          headline: s.headline || s.hazard?.name || 'Potential Health Hazard',
          summary: s.summary || s.lingua?.translation_text || 'Monitoring incoming signal data...',
          hazard: {
            name: s.hazard?.name || 'Unknown Hazard',
            category: s.hazard?.category || 'Uncategorized',
            who_afro_code: s.hazard?.who_afro_code || 'N/A',
            type: s.hazard?.type || 'disease'
          },
          location: {
            country: s.location?.country || location || 'Unknown',
            country_iso: s.location?.country_iso || 'AFR',
            admin1: s.location?.admin1 || ''
          },
          epi: s.epi || { cases_suspected: 0, deaths: 0 },
          lingua: {
            ...s.lingua,
            original_text: s.lingua?.original_text || '',
            original_language_name: s.lingua?.original_language_name || 'English',
            translation_text: s.lingua?.translation_text || '',
            local_voice: s.lingua?.local_voice || false,
            detected_keywords: s.lingua?.detected_keywords || []
          },
          sources: (s.sources && s.sources.length > 0) ? s.sources : [{ name: 'AFRO Sentinel', type: 'Official', tier: 1, icon: '📡' }],
          tags: s.lingua?.local_voice ? ['🏠 LOCAL VOICE'] : []
        };
      });
    });

    INTEL_CACHE[cacheKey] = { data, timestamp: Date.now() };
    return data;
  } catch (error: any) {
    console.error("Watchtower API Error:", error);
    // Return cached data even if expired if we hit an error to maintain UX
    return INTEL_CACHE[cacheKey]?.data || [];
  }
};

/**
 * GROUNDED INTELLIGENCE: Fetches situational reports using Google Search data.
 */
export const fetchRegionalIntelligence = async (): Promise<RegionalSummary[]> => {
  const cacheKey = 'regional_intel';
  if (INTEL_CACHE[cacheKey] && Date.now() - INTEL_CACHE[cacheKey].timestamp < CACHE_TTL) {
    return INTEL_CACHE[cacheKey].data;
  }

  try {
    const data = await withRetry(async () => {
      // Explicitly typing the response to GenerateContentResponse to fix 'unknown' type errors
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: "Analyze recent news and health bulletins from the last 7 days. Provide a situational report for the top 5 active disease outbreaks specifically within the WHO Africa Region. Ensure counts for 'countriesAffected' and 'totalEstimatedCases' reflect current grounded data.",
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                disease: { type: Type.STRING },
                trend: { type: Type.STRING },
                countriesAffected: { type: Type.NUMBER },
                countriesList: { type: Type.ARRAY, items: { type: Type.STRING } },
                totalEstimatedCases: { type: Type.NUMBER }
              }
            }
          }
        }
      });
      const text = response.text;
      return text ? JSON.parse(text) : [];
    });
    
    INTEL_CACHE[cacheKey] = { data, timestamp: Date.now() };
    return data;
  } catch (error) {
    console.error("Regional Intel Error:", error);
    return INTEL_CACHE[cacheKey]?.data || [];
  }
};

/**
 * FAST BRIEFING: Low-latency situational summary using Gemini Flash-Lite.
 */
export const fetchFastBriefing = async (location: string): Promise<string> => {
  try {
    // Ensuring withRetry generic type T is GenerateContentResponse to correctly infer .text property
    const response = await withRetry<GenerateContentResponse>(() => ai.models.generateContent({
      model: 'gemini-2.5-flash-lite-latest',
      contents: `Provide a 3-sentence high-level executive briefing on the current health hazard status for ${location}. Focus on immediate threats.`
    }));
    return response.text || "Briefing unavailable.";
  } catch (error) {
    console.error("Fast Briefing Error:", error);
    return "Intelligence sync delayed.";
  }
};

/**
 * DEEP REASONING: Answers complex user queries about pathogens or trends.
 */
export const askDeepIntelligence = async (query: string): Promise<string> => {
  try {
    // Ensuring withRetry generic type T is GenerateContentResponse to correctly infer .text property
    const response = await withRetry<GenerateContentResponse>(() => ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: query,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      }
    }));
    return response.text || "Deep analysis completed but no response returned.";
  } catch (error) {
    console.error("Deep Intelligence Error:", error);
    return "Neural analysis failed due to system load. Please try again in 60 seconds.";
  }
};

export const fetchRegionalSignals = async (): Promise<Signal[]> => {
  return fetchLiveSignals("the WHO Africa Region");
};
